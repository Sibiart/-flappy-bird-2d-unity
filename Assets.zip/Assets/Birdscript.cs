using UnityEngine;
using UnityEngine.InputSystem;
public class Birdscript : MonoBehaviour
{
    public Rigidbody2D myrigidbody;
    public float flapstrength = 12;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        myrigidbody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {


        if (Keyboard.current.spaceKey.wasPressedThisFrame)
        {
            myrigidbody.linearVelocity = Vector2.up * flapstrength;
        }
    }
}
