using UnityEngine;

public class pipescript : MonoBehaviour
{
    public float moveSpeed = 5;
    public float deadpipezone = -45;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < deadpipezone)
            {
            Debug.Log("Pipe Deleted");
            Destroy(gameObject);
        }
        transform.position += Vector3.left * moveSpeed * Time.deltaTime;
    }
}
